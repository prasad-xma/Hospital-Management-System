package com.hms.server.dto;

import com.hms.server.model.Patient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientResponse {
    private String patientId;
    private String firstName;
    private String lastName;
    private String email;
    private int age;
    private boolean active;

    public static PatientResponse fromPatient(Patient patient) {
        PatientResponse response = new PatientResponse();
        response.setPatientId(patient.getPatientId());
        response.setFirstName(patient.getFirstName());
        response.setLastName(patient.getLastName());
        response.setEmail(patient.getEmail());
        response.setAge(patient.getAge());
        response.setActive(patient.isActive());
        return response;
    }
}
